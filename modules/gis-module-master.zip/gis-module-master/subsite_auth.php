<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Is the module published for every subsite?
$public                 = FALSE;
// In case of $public is FALSE, what are subsites allowed to use this module?
$subsite_allowed        = array();