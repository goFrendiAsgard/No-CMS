<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_table_prefix']  = 'gis';
$config['module_prefix']        = 'gis';