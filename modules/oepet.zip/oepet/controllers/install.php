<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Installation script for oepet
 *
 * @author No-CMS Module Generator
 */
class Install extends CMS_Module_Installer {
    /////////////////////////////////////////////////////////////////////////////
    // Default Variables
    /////////////////////////////////////////////////////////////////////////////

    protected $DEPENDENCIES = array();
    protected $NAME         = 'gofrendi.oepet';
    protected $DESCRIPTION  = 'Ongkowidjojo';
    protected $VERSION      = '0.0.0';

    public function cms_complete_table_name($table_name){
        $this->load->helper($this->cms_module_path().'/function');
        if(function_exists('cms_complete_table_name')){
            return cms_complete_table_name($table_name);
        }else{
            return parent::cms_complete_table_name($table_name);
        }
    }


    /////////////////////////////////////////////////////////////////////////////
    // Default Functions
    /////////////////////////////////////////////////////////////////////////////

    // ACTIVATION
    protected function do_activate(){
        $this->remove_all();
        $this->build_all();
    }

    // DEACTIVATION
    protected function do_deactivate(){
        /*
        $this->backup_database(array(
            $this->cms_complete_table_name('master_gudang'),
            $this->cms_complete_table_name('master_bahan'),
            $this->cms_complete_table_name('master_bahanpendukung'),
            $this->cms_complete_table_name('master_rokok'),
            $this->cms_complete_table_name('master_aktivitas'),
            $this->cms_complete_table_name('master_agen'),
            $this->cms_complete_table_name('master_mesin'),
            $this->cms_complete_table_name('master_mobil'),
            $this->cms_complete_table_name('master_supir'),
            $this->cms_complete_table_name('master_kernet'),
            $this->cms_complete_table_name('master_jasaekspedisi'),
            $this->cms_complete_table_name('master_supplier'),
            $this->cms_complete_table_name('trans_purchaseorder'),
            $this->cms_complete_table_name('trans_order_preprimary'),
            $this->cms_complete_table_name('trans_order_primary'),
            $this->cms_complete_table_name('trans_order_secondary'),
            $this->cms_complete_table_name('trans_beritaacara_preprimary'),
            $this->cms_complete_table_name('trans_beritaacara_primary'),
            $this->cms_complete_table_name('trans_beritaacara_secondary'),
            $this->cms_complete_table_name('trans_beritaacara_delivery'),
            $this->cms_complete_table_name('trans_fakturpenjualan'),
            $this->cms_complete_table_name('trans_stokopname'),
            $this->cms_complete_table_name('trans_detail_fakturpenjualan'),
            $this->cms_complete_table_name('history_harga_bahan'),
            $this->cms_complete_table_name('historyharga_bahanpendukung'),
            $this->cms_complete_table_name('history_harga_aktivitas'),
            $this->cms_complete_table_name('cache_kesiapan_bip'),
            $this->cms_complete_table_name('cache_kesiapan_bipp'),
            $this->cms_complete_table_name('cache_kesiapan_bop'),
            $this->cms_complete_table_name('cache_kesiapan_bp'),
            $this->cms_complete_table_name('history_harga_rokok'),
            $this->cms_complete_table_name('korelasi_bom_bop_aktivitas'),
            $this->cms_complete_table_name('korelasi_bom_bop_bip'),
            $this->cms_complete_table_name('korelasi_bom_bopp_aktivitas'),
            $this->cms_complete_table_name('korelasi_bom_bopp_bipp'),
            $this->cms_complete_table_name('korelasi_bom_rokok_aktivitas'),
            $this->cms_complete_table_name('korelasi_bom_rokok_bop'),
            $this->cms_complete_table_name('korelasi_bom_rokok_bp'),
            $this->cms_complete_table_name('master_aktivitas_satuan'),
            $this->cms_complete_table_name('master_bahan_satuan'),
            $this->cms_complete_table_name('master_bahanpendukung_satuan'),
            $this->cms_complete_table_name('master_rokok_satuan'),
            $this->cms_complete_table_name('trans_detail_beritaacara_delivery'),
            $this->cms_complete_table_name('trans_detail_beritaacara_preprimary'),
            $this->cms_complete_table_name('trans_detail_beritaacara_preprimary_aktivitas'),
            $this->cms_complete_table_name('trans_detail_beritaacara_preprimary_bipp'),
            $this->cms_complete_table_name('trans_detail_beritaacara_primary'),
            $this->cms_complete_table_name('trans_detail_beritaacara_primary_aktivitas'),
            $this->cms_complete_table_name('trans_detail_beritaacara_primary_bopp'),
            $this->cms_complete_table_name('trans_detail_beritaacara_secondary'),
            $this->cms_complete_table_name('trans_detail_beritaacara_secondary_aktivitas'),
            $this->cms_complete_table_name('trans_detail_beritaacara_secondary_bop'),
            $this->cms_complete_table_name('trans_detail_beritaacara_secondary_bp'),
            $this->cms_complete_table_name('trans_detail_keluar_rokok'),
            $this->cms_complete_table_name('trans_detail_masuk_bipp'),
            $this->cms_complete_table_name('trans_detail_masuk_bp'),
            $this->cms_complete_table_name('trans_detail_order_preprimary'),
            $this->cms_complete_table_name('trans_detail_order_primary'),
            $this->cms_complete_table_name('trans_detail_order_secondary'),
            $this->cms_complete_table_name('trans_detail_purchaseorder'),
            $this->cms_complete_table_name('trans_detail_spk_preprimary'),
            $this->cms_complete_table_name('trans_detail_spk_primary'),
            $this->cms_complete_table_name('trans_detail_spk_secondary'),
            $this->cms_complete_table_name('trans_detail_stokopname_bahan'),
            $this->cms_complete_table_name('trans_detail_stokopname_bp'),
            $this->cms_complete_table_name('trans_detail_stokopname_rokok'),
            $this->cms_complete_table_name('trans_keluar_rokok'),
            $this->cms_complete_table_name('trans_masuk_bipp'),
            $this->cms_complete_table_name('trans_masuk_bp'),
            $this->cms_complete_table_name('trans_spk_preprimary'),
            $this->cms_complete_table_name('trans_spk_primary'),
            $this->cms_complete_table_name('trans_spk_secondary')
        ));*/
        $this->remove_all();
    }

    // UPGRADE
    protected function do_upgrade($old_version){
        // Add your migration logic here.
    }

    // OVERRIDE THIS FUNCTION TO PROVIDE "Module Setting" FEATURE
    public function setting(){
        $module_directory = $this->cms_module_path();
        $data = array();
        $data['IS_ACTIVE'] = $this->IS_ACTIVE;
        $data['module_directory'] = $module_directory;
        if(!$this->IS_ACTIVE){
            // get setting
            $module_table_prefix = $this->input->post('module_table_prefix');
            $module_prefix       = $this->input->post('module_prefix');
            // set values
            if(isset($module_table_prefix) && $module_table_prefix !== FALSE){
                cms_module_config($module_directory, 'module_table_prefix', $module_table_prefix);
            }
            if(isset($module_prefix) && $module_prefix !== FALSE){
                cms_module_prefix($module_directory, $module_prefix);
            }
            // get values
            $data['module_table_prefix'] = cms_module_config($module_directory, 'module_table_prefix');
            $data['module_prefix']       = cms_module_prefix($module_directory);
        }
        $this->view($module_directory.'/install_setting', $data, 'main_module_management');
    }

    /////////////////////////////////////////////////////////////////////////////
    // Private Functions
    /////////////////////////////////////////////////////////////////////////////

    // REMOVE ALL NAVIGATIONS, WIDGETS, AND PRIVILEGES
    private function remove_all(){
        $module_path = $this->cms_module_path();

        // remove navigations
        // t_master_gudang
        $this->remove_navigation($this->cms_complete_navigation_name('master_gudang'));

        // t_master_bahan
        $this->remove_navigation($this->cms_complete_navigation_name('master_bahan_preprimary_primary'));
        $this->remove_navigation($this->cms_complete_navigation_name('setting_harga_preprimary'));
        $this->remove_navigation($this->cms_complete_navigation_name('bom_output_preprimary'));
        $this->remove_navigation($this->cms_complete_navigation_name('bom_output_primary'));

        // t_master_bahan_pendukung
        $this->remove_navigation($this->cms_complete_navigation_name('master_bahan_pendukung'));

        // t_master_rokok
        $this->remove_navigation($this->cms_complete_navigation_name('master_rokok'));
        $this->remove_navigation($this->cms_complete_navigation_name('bom_output_secondary'));        

        // t_master_aktivitas
        $this->remove_navigation($this->cms_complete_navigation_name('master_aktivitas'));
        $this->remove_navigation($this->cms_complete_navigation_name('setting_harga_aktivitas_operasional'));

        // t_master_agen
        $this->remove_navigation($this->cms_complete_navigation_name('master_agen'));

        // t_master_mesin
        $this->remove_navigation($this->cms_complete_navigation_name('master_mesin'));

        // t_master_mobil
        $this->remove_navigation($this->cms_complete_navigation_name('master_mobil'));

        // t_master_supir
        $this->remove_navigation($this->cms_complete_navigation_name('master_supir'));

        // t_master_kernet
        $this->remove_navigation($this->cms_complete_navigation_name('master_kernet'));

        // t_master_supplier
        $this->remove_navigation($this->cms_complete_navigation_name('master_supplier'));

        // t_master_jasaekspedisi
        $this->remove_navigation($this->cms_complete_navigation_name('master_jasa_ekspedisi'));

        // t_trans_purchaseorder
        $this->remove_navigation($this->cms_complete_navigation_name('trans_purchase_order'));

        // t_trans_order_preprimary
        $this->remove_navigation($this->cms_complete_navigation_name('trans_order_preprimary'));

        // t_trans_order_primary
        $this->remove_navigation($this->cms_complete_navigation_name('trans_order_primary'));

        // t_trans_order_secondary
        $this->remove_navigation($this->cms_complete_navigation_name('trans_order_secondary'));
        
        // t_trans_beritaacara_preprimary
        $this->remove_navigation($this->cms_complete_navigation_name('trans_berita_acara_preprimary'));

        // t_trans_beritaacara_primary
        $this->remove_navigation($this->cms_complete_navigation_name('trans_berita_acara_primary'));

        // t_trans_beritaacara_secondary
        $this->remove_navigation($this->cms_complete_navigation_name('trans_berita_acara_secondary'));

        // t_trans_beritaacara_delivery
        $this->remove_navigation($this->cms_complete_navigation_name('trans_berita_acara_delivery'));
        $this->remove_navigation($this->cms_complete_navigation_name('surat_jalan'));

        // t_trans_faktur_pernjualan
        $this->remove_navigation($this->cms_complete_navigation_name('trans_faktur_penjualan'));

        // t_trans_stok_opname
        $this->remove_navigation($this->cms_complete_navigation_name('trans_stok_opname'));


        // remove parent of all navigations
        $this->remove_quicklink($this->cms_complete_navigation_name('index'));
        $this->remove_navigation($this->cms_complete_navigation_name('index'));
    }

    // CREATE ALL NAVIGATIONS, WIDGETS, AND PRIVILEGES
    private function build_all(){
        $module_path = $this->cms_module_path();

        // parent of all navigations
        $this->add_navigation($this->cms_complete_navigation_name('index'), 'Oepet',
            $module_path.'/oepet', $this->PRIV_EVERYONE);
        $this->add_quicklink($this->cms_complete_navigation_name('index'));

        // t_master_gudang
        $this->add_navigation($this->cms_complete_navigation_name('master_gudang'), 'Master Gudang',
            $module_path.'/manage_master_gudang', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_bahan
        $this->add_navigation($this->cms_complete_navigation_name('master_bahan_preprimary_primary'), 'Master Bahan Preprimary dan Primary',
            $module_path.'/manage_master_bahan/index/preprimary_primary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );
        $this->add_navigation($this->cms_complete_navigation_name('setting_harga_preprimary'), 'Setting Harga Bahan Preprimary',
            $module_path.'/manage_master_bahan/index/setting_harga_preprimary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );
        $this->add_navigation($this->cms_complete_navigation_name('bom_output_preprimary'), 'Bill of Material Output Preprimary',
            $module_path.'/manage_master_bahan/index/bom_output_preprimary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );
        $this->add_navigation($this->cms_complete_navigation_name('bom_output_primary'), 'Bill of Material Output Primary',
            $module_path.'/manage_master_bahan/index/bom_output_primary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_bahan_pendukung
        $this->add_navigation($this->cms_complete_navigation_name('master_bahan_pendukung'), 'Master Bahan Pendukung',
            $module_path.'/manage_master_bahanpendukung', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_rokok
        $this->add_navigation($this->cms_complete_navigation_name('master_rokok'), 'Master Rokok',
            $module_path.'/manage_master_rokok/index/manage', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );
        $this->add_navigation($this->cms_complete_navigation_name('bom_output_secondary'), 'Bill of Material Output Secondary',
            $module_path.'/manage_master_rokok/index/bom_output_secondary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );        

        // t_master_aktivitas
        $this->add_navigation($this->cms_complete_navigation_name('master_aktivitas'), 'Master Aktivitas',
            $module_path.'/manage_master_aktivitas/index/manage', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );
        $this->add_navigation($this->cms_complete_navigation_name('setting_harga_aktivitas_operasional'), 'Setting Harga Aktivitas Operasional',
            $module_path.'/manage_master_aktivitas/index/setting_harga_aktivitas_operasional', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_agen
        $this->add_navigation($this->cms_complete_navigation_name('master_agen'), 'Master Agen',
            $module_path.'/manage_master_agen', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_mesin
        $this->add_navigation($this->cms_complete_navigation_name('master_mesin'), 'Master Mesin',
            $module_path.'/manage_master_mesin', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_mobil
        $this->add_navigation($this->cms_complete_navigation_name('master_mobil'), 'Master Mobil',
            $module_path.'/manage_master_mobil', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_supir
        $this->add_navigation($this->cms_complete_navigation_name('master_supir'), 'Master Supir',
            $module_path.'/manage_master_supir', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_kernet
        $this->add_navigation($this->cms_complete_navigation_name('master_kernet'), 'Master Kernet',
            $module_path.'/manage_master_kernet', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_supplier
        $this->add_navigation($this->cms_complete_navigation_name('master_supplier'), 'Master Supplier',
            $module_path.'/manage_master_supplier', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_master_jasaekspedisi
        $this->add_navigation($this->cms_complete_navigation_name('master_jasa_ekspedisi'), 'Master Jasa Ekspedisi',
            $module_path.'/manage_master_jasaekspedisi', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_purchaseorder
        $this->add_navigation($this->cms_complete_navigation_name('trans_purchase_order'), 'Transaksi Purchase Order',
            $module_path.'/manage_trans_purchaseorder', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_order_preprimary
        $this->add_navigation($this->cms_complete_navigation_name('trans_order_preprimary'), 'Notifikasi dan Tracking Preprimary',
            $module_path.'/manage_trans_order_preprimary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_order_primary
        $this->add_navigation($this->cms_complete_navigation_name('trans_order_primary'), 'Notifikasi dan Tracking Primary',
            $module_path.'/manage_trans_order_primary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_order_secondary
        $this->add_navigation($this->cms_complete_navigation_name('trans_order_secondary'), 'Notifikasi dan Tracking Secondary',
            $module_path.'/manage_trans_order_secondary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );
        
        // t_trans_beritaacara_preprimary
        $this->add_navigation($this->cms_complete_navigation_name('trans_berita_acara_preprimary'), 'Berita Acara Produksi Preprimary',
            $module_path.'/manage_trans_beritaacara_preprimary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_beritaacara_primary
        $this->add_navigation($this->cms_complete_navigation_name('trans_berita_acara_primary'), 'Berita Acara Produksi Primary',
            $module_path.'/manage_trans_beritaacara_primary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_beritaacara_secondary
        $this->add_navigation($this->cms_complete_navigation_name('trans_berita_acara_secondary'), 'Berita Acara Produksi Secondary',
            $module_path.'/manage_trans_beritaacara_secondary', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_beritaacara_delivery
        $this->add_navigation($this->cms_complete_navigation_name('trans_berita_acara_delivery'), 'Berita Acara Delivery',
            $module_path.'/manage_trans_beritaacara_delivery/index/manage', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );
        $this->add_navigation($this->cms_complete_navigation_name('surat_jalan'), 'Surat Jalan',
            $module_path.'/manage_trans_beritaacara_delivery/index/surat_jalan', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_faktur_pernjualan
        $this->add_navigation($this->cms_complete_navigation_name('trans_faktur_penjualan'), 'Faktur Penjualan',
            $module_path.'/manage_trans_fakturpenjualan', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );

        // t_trans_stok_opname
        $this->add_navigation($this->cms_complete_navigation_name('trans_stok_opname'), 'Stok Opname',
            $module_path.'/manage_trans_stokopname', $this->PRIV_AUTHORIZED, $this->cms_complete_navigation_name('index')
        );


        // create tables
        $sql_str = file_get_contents(FCPATH.'modules/'.$this->cms_module_path().'/assets/db/install.sql');
        $sql_command_list = explode(';', $sql_str);
        foreach($sql_command_list as $sql_command){
            $this->db->query($sql_command);
        }


    }

    // EXPORT DATABASE
    private function backup_database($table_names, $limit = 100){
        if($this->db->platform() == 'mysql' || $this->db->platform() == 'mysqli'){
            $module_path = $this->cms_module_path();
            $this->load->dbutil();
            $sql = '';

            // create DROP TABLE syntax
            for($i=count($table_names)-1; $i>=0; $i--){
                $table_name = $table_names[$i];
                $sql .= 'DROP TABLE IF EXISTS `'.$table_name.'`; '.PHP_EOL;
            }
            if($sql !='')$sql.= PHP_EOL;

            // create CREATE TABLE and INSERT syntax

            $prefs = array(
                    'tables'      => $table_names,
                    'ignore'      => array(),
                    'format'      => 'txt',
                    'filename'    => 'mybackup.sql',
                    'add_drop'    => FALSE,
                    'add_insert'  => TRUE,
                    'newline'     => PHP_EOL
                  );
            $sql.= @$this->dbutil->backup($prefs);

            //write file
            $file_name = 'backup_'.date('Y-m-d_G-i-s').'.sql';
            file_put_contents(
                    BASEPATH.'../modules/'.$module_path.'/assets/db/'.$file_name,
                    $sql
                );
        }

    }
}
