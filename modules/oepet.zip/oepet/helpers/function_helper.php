<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function cms_complete_table_name($table_name){
    return 't_'.$table_name;
}
