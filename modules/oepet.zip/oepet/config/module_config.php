<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['module_table_prefix']  = 't';
$config['module_prefix']        = 'oepet';