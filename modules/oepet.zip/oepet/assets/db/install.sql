-- MySQL dump 10.13  Distrib 5.5.38, for debian-linux-gnu (i686)
--
-- Host: 127.0.0.1    Database: oepet
-- ------------------------------------------------------
-- Server version	5.5.38-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_cache_kesiapan_bip`
--

DROP TABLE IF EXISTS `t_cache_kesiapan_bip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cache_kesiapan_bip` (
  `IDKesiapanBIP` int(11) NOT NULL,
  `IDOrderPrimary` int(11) NOT NULL,
  `IDBIP` int(11) NOT NULL,
  `Dibutuhkan` float NOT NULL DEFAULT '1',
  `Tersedia` float NOT NULL DEFAULT '1',
  `Alasan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDKesiapanBIP`),
  KEY `IDOrderPrimary` (`IDOrderPrimary`),
  KEY `IDBIP` (`IDBIP`),
  CONSTRAINT `t_cache_kesiapan_bip_ibfk_1` FOREIGN KEY (`IDOrderPrimary`) REFERENCES `t_trans_order_primary` (`IDOrderPrimary`),
  CONSTRAINT `t_cache_kesiapan_bip_ibfk_2` FOREIGN KEY (`IDBIP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cache_kesiapan_bip`
--

LOCK TABLES `t_cache_kesiapan_bip` WRITE;
/*!40000 ALTER TABLE `t_cache_kesiapan_bip` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_cache_kesiapan_bip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cache_kesiapan_bipp`
--

DROP TABLE IF EXISTS `t_cache_kesiapan_bipp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cache_kesiapan_bipp` (
  `IDKesiapanBIPP` int(11) NOT NULL AUTO_INCREMENT,
  `IDOrderPrePrimary` int(11) NOT NULL,
  `IDBIPP` int(11) NOT NULL,
  `Dibutuhkan` float NOT NULL DEFAULT '1',
  `Tersedia` float NOT NULL DEFAULT '1',
  `Alasan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDKesiapanBIPP`),
  KEY `IDOrderPrePrimary` (`IDOrderPrePrimary`),
  KEY `IDBIPP` (`IDBIPP`),
  CONSTRAINT `t_cache_kesiapan_bipp_ibfk_1` FOREIGN KEY (`IDOrderPrePrimary`) REFERENCES `t_trans_order_preprimary` (`IDOrderPrePrimary`),
  CONSTRAINT `t_cache_kesiapan_bipp_ibfk_2` FOREIGN KEY (`IDBIPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cache_kesiapan_bipp`
--

LOCK TABLES `t_cache_kesiapan_bipp` WRITE;
/*!40000 ALTER TABLE `t_cache_kesiapan_bipp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_cache_kesiapan_bipp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cache_kesiapan_bop`
--

DROP TABLE IF EXISTS `t_cache_kesiapan_bop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cache_kesiapan_bop` (
  `IDKesiapanBOP` int(11) NOT NULL,
  `IDOrderSecondary` int(11) NOT NULL,
  `IDBOP` int(11) NOT NULL,
  `Dibutuhkan` float NOT NULL DEFAULT '1',
  `Tersedia` float NOT NULL DEFAULT '1',
  `Alasan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDKesiapanBOP`),
  KEY `IDOrderSecondary` (`IDOrderSecondary`),
  KEY `IDBOP` (`IDBOP`),
  CONSTRAINT `t_cache_kesiapan_bop_ibfk_1` FOREIGN KEY (`IDOrderSecondary`) REFERENCES `t_trans_order_secondary` (`IDOrderSecondary`),
  CONSTRAINT `t_cache_kesiapan_bop_ibfk_2` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cache_kesiapan_bop`
--

LOCK TABLES `t_cache_kesiapan_bop` WRITE;
/*!40000 ALTER TABLE `t_cache_kesiapan_bop` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_cache_kesiapan_bop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_cache_kesiapan_bp`
--

DROP TABLE IF EXISTS `t_cache_kesiapan_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cache_kesiapan_bp` (
  `IDKesiapanBOP` int(11) NOT NULL,
  `IDOrderSecondary` int(11) NOT NULL,
  `IDBP` int(11) NOT NULL,
  `Dibutuhkan` float NOT NULL DEFAULT '1',
  `Tersedia` float NOT NULL DEFAULT '1',
  `Alasan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDKesiapanBOP`),
  KEY `IDOrderSecondary` (`IDOrderSecondary`),
  KEY `IDBP` (`IDBP`),
  CONSTRAINT `t_cache_kesiapan_bp_ibfk_1` FOREIGN KEY (`IDOrderSecondary`) REFERENCES `t_trans_order_secondary` (`IDOrderSecondary`),
  CONSTRAINT `t_cache_kesiapan_bp_ibfk_2` FOREIGN KEY (`IDBP`) REFERENCES `t_master_bahanpendukung` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cache_kesiapan_bp`
--

LOCK TABLES `t_cache_kesiapan_bp` WRITE;
/*!40000 ALTER TABLE `t_cache_kesiapan_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_cache_kesiapan_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_history_harga_aktivitas`
--

DROP TABLE IF EXISTS `t_history_harga_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_history_harga_aktivitas` (
  `IDHistoryHarga` int(11) NOT NULL AUTO_INCREMENT,
  `IDSatuan` int(11) NOT NULL,
  `Harga` float NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  PRIMARY KEY (`IDHistoryHarga`),
  KEY `IDSatuan` (`IDSatuan`),
  CONSTRAINT `t_history_harga_aktivitas_ibfk_1` FOREIGN KEY (`IDSatuan`) REFERENCES `t_master_aktivitas_satuan` (`IDSatuanLain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_history_harga_aktivitas`
--

LOCK TABLES `t_history_harga_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_history_harga_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_history_harga_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_history_harga_bahan`
--

DROP TABLE IF EXISTS `t_history_harga_bahan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_history_harga_bahan` (
  `IDHistoryHarga` int(11) NOT NULL AUTO_INCREMENT,
  `IDSatuan` int(11) NOT NULL,
  `Harga` float NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  PRIMARY KEY (`IDHistoryHarga`),
  KEY `IDSatuan` (`IDSatuan`),
  CONSTRAINT `t_history_harga_bahan_ibfk_1` FOREIGN KEY (`IDSatuan`) REFERENCES `t_master_bahan_satuan` (`IDSatuanLain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_history_harga_bahan`
--

LOCK TABLES `t_history_harga_bahan` WRITE;
/*!40000 ALTER TABLE `t_history_harga_bahan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_history_harga_bahan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_history_harga_rokok`
--

DROP TABLE IF EXISTS `t_history_harga_rokok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_history_harga_rokok` (
  `IDHistoryHarga` int(11) NOT NULL AUTO_INCREMENT,
  `IDSatuan` int(11) NOT NULL,
  `Harga` float NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  PRIMARY KEY (`IDHistoryHarga`),
  KEY `IDSatuan` (`IDSatuan`),
  CONSTRAINT `t_history_harga_rokok_ibfk_1` FOREIGN KEY (`IDSatuan`) REFERENCES `t_master_rokok_satuan` (`IDSatuanLain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_history_harga_rokok`
--

LOCK TABLES `t_history_harga_rokok` WRITE;
/*!40000 ALTER TABLE `t_history_harga_rokok` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_history_harga_rokok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_historyharga_bahanpendukung`
--

DROP TABLE IF EXISTS `t_historyharga_bahanpendukung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_historyharga_bahanpendukung` (
  `IDHistoryHarga` int(11) NOT NULL AUTO_INCREMENT,
  `IDSatuan` int(11) NOT NULL,
  `Harga` float NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  PRIMARY KEY (`IDHistoryHarga`),
  KEY `IDSatuan` (`IDSatuan`),
  CONSTRAINT `t_historyharga_bahanpendukung_ibfk_1` FOREIGN KEY (`IDSatuan`) REFERENCES `t_master_bahanpendukung_satuan` (`IDSatuanLain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_historyharga_bahanpendukung`
--

LOCK TABLES `t_historyharga_bahanpendukung` WRITE;
/*!40000 ALTER TABLE `t_historyharga_bahanpendukung` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_historyharga_bahanpendukung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_korelasi_bom_bop_aktivitas`
--

DROP TABLE IF EXISTS `t_korelasi_bom_bop_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_korelasi_bom_bop_aktivitas` (
  `IDBOM` int(11) NOT NULL AUTO_INCREMENT,
  `IDBOP` int(11) NOT NULL,
  `IDProses` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Toleransi` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDBOM`),
  KEY `IDProses` (`IDProses`),
  KEY `IDBOP` (`IDBOP`),
  CONSTRAINT `t_korelasi_bom_bop_aktivitas_ibfk_2` FOREIGN KEY (`IDProses`) REFERENCES `t_master_aktivitas` (`IDProses`),
  CONSTRAINT `t_korelasi_bom_bop_aktivitas_ibfk_3` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_korelasi_bom_bop_aktivitas`
--

LOCK TABLES `t_korelasi_bom_bop_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_korelasi_bom_bop_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_korelasi_bom_bop_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_korelasi_bom_bop_bip`
--

DROP TABLE IF EXISTS `t_korelasi_bom_bop_bip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_korelasi_bom_bop_bip` (
  `IDBOM` int(11) NOT NULL AUTO_INCREMENT,
  `IDBOP` int(11) NOT NULL,
  `IDBIP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Toleransi` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDBOM`),
  KEY `IDBOP` (`IDBOP`),
  KEY `IDBIP` (`IDBIP`),
  CONSTRAINT `t_korelasi_bom_bop_bip_ibfk_1` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`),
  CONSTRAINT `t_korelasi_bom_bop_bip_ibfk_2` FOREIGN KEY (`IDBIP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_korelasi_bom_bop_bip`
--

LOCK TABLES `t_korelasi_bom_bop_bip` WRITE;
/*!40000 ALTER TABLE `t_korelasi_bom_bop_bip` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_korelasi_bom_bop_bip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_korelasi_bom_bopp_aktivitas`
--

DROP TABLE IF EXISTS `t_korelasi_bom_bopp_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_korelasi_bom_bopp_aktivitas` (
  `IDBOM` int(11) NOT NULL AUTO_INCREMENT,
  `IDBOPP` int(11) NOT NULL,
  `IDProses` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Toleransi` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDBOM`),
  KEY `IDProses` (`IDProses`),
  KEY `IDBOPP` (`IDBOPP`),
  CONSTRAINT `t_korelasi_bom_bopp_aktivitas_ibfk_2` FOREIGN KEY (`IDProses`) REFERENCES `t_master_aktivitas` (`IDProses`),
  CONSTRAINT `t_korelasi_bom_bopp_aktivitas_ibfk_3` FOREIGN KEY (`IDBOPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_korelasi_bom_bopp_aktivitas`
--

LOCK TABLES `t_korelasi_bom_bopp_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_korelasi_bom_bopp_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_korelasi_bom_bopp_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_korelasi_bom_bopp_bipp`
--

DROP TABLE IF EXISTS `t_korelasi_bom_bopp_bipp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_korelasi_bom_bopp_bipp` (
  `IDBOM` int(11) NOT NULL AUTO_INCREMENT,
  `IDBOPP` int(11) NOT NULL,
  `IDBIPP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Toleransi` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDBOM`),
  KEY `IDBOPP` (`IDBOPP`),
  KEY `IDBIPP` (`IDBIPP`),
  CONSTRAINT `t_korelasi_bom_bopp_bipp_ibfk_1` FOREIGN KEY (`IDBOPP`) REFERENCES `t_master_bahan` (`IDBahan`),
  CONSTRAINT `t_korelasi_bom_bopp_bipp_ibfk_2` FOREIGN KEY (`IDBIPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_korelasi_bom_bopp_bipp`
--

LOCK TABLES `t_korelasi_bom_bopp_bipp` WRITE;
/*!40000 ALTER TABLE `t_korelasi_bom_bopp_bipp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_korelasi_bom_bopp_bipp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_korelasi_bom_rokok_aktivitas`
--

DROP TABLE IF EXISTS `t_korelasi_bom_rokok_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_korelasi_bom_rokok_aktivitas` (
  `IDBOM` int(11) NOT NULL AUTO_INCREMENT,
  `IDRokok` int(11) NOT NULL,
  `IDProses` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Toleransi` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDBOM`),
  KEY `IDProses` (`IDProses`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_korelasi_bom_rokok_aktivitas_ibfk_2` FOREIGN KEY (`IDProses`) REFERENCES `t_master_aktivitas` (`IDProses`),
  CONSTRAINT `t_korelasi_bom_rokok_aktivitas_ibfk_3` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_korelasi_bom_rokok_aktivitas`
--

LOCK TABLES `t_korelasi_bom_rokok_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_korelasi_bom_rokok_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_korelasi_bom_rokok_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_korelasi_bom_rokok_bop`
--

DROP TABLE IF EXISTS `t_korelasi_bom_rokok_bop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_korelasi_bom_rokok_bop` (
  `IDBOM` int(11) NOT NULL AUTO_INCREMENT,
  `IDRokok` int(11) NOT NULL,
  `IDBOP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Toleransi` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDBOM`),
  KEY `IDBOP` (`IDBOP`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_korelasi_bom_rokok_bop_ibfk_2` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`),
  CONSTRAINT `t_korelasi_bom_rokok_bop_ibfk_3` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_korelasi_bom_rokok_bop`
--

LOCK TABLES `t_korelasi_bom_rokok_bop` WRITE;
/*!40000 ALTER TABLE `t_korelasi_bom_rokok_bop` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_korelasi_bom_rokok_bop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_korelasi_bom_rokok_bp`
--

DROP TABLE IF EXISTS `t_korelasi_bom_rokok_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_korelasi_bom_rokok_bp` (
  `IDBOM` int(11) NOT NULL AUTO_INCREMENT,
  `IDRokok` int(11) NOT NULL,
  `IDBP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Toleransi` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`IDBOM`),
  KEY `IDRokok` (`IDRokok`),
  KEY `IDBP` (`IDBP`),
  CONSTRAINT `t_korelasi_bom_rokok_bp_ibfk_3` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`),
  CONSTRAINT `t_korelasi_bom_rokok_bp_ibfk_4` FOREIGN KEY (`IDBP`) REFERENCES `t_master_bahanpendukung` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_korelasi_bom_rokok_bp`
--

LOCK TABLES `t_korelasi_bom_rokok_bp` WRITE;
/*!40000 ALTER TABLE `t_korelasi_bom_rokok_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_korelasi_bom_rokok_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_agen`
--

DROP TABLE IF EXISTS `t_master_agen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_agen` (
  `IDAgen` int(11) NOT NULL AUTO_INCREMENT,
  `KodeAgen` varchar(13) NOT NULL,
  `Nama` varchar(35) NOT NULL,
  `NamaPerusahaan` varchar(35) NOT NULL,
  `Alamat` varchar(40) NOT NULL,
  `NoTelpon` varchar(20) NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDAgen`),
  KEY `KodeAgen` (`KodeAgen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_agen`
--

LOCK TABLES `t_master_agen` WRITE;
/*!40000 ALTER TABLE `t_master_agen` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_agen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_aktivitas`
--

DROP TABLE IF EXISTS `t_master_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_aktivitas` (
  `IDProses` int(11) NOT NULL AUTO_INCREMENT,
  `KodeProses` varchar(8) NOT NULL,
  `JenisProses` varchar(30) NOT NULL COMMENT 'PROSES MESIN\r\nPROSES SIMPAN\r\nPROSES PENGIRIMAN\r\nTENAGA KERJA\r\nBAHAN HABIS PAKAI\r\nOPERASIONAL LAIN',
  `Nama` varchar(35) NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDProses`),
  UNIQUE KEY `KodeProses` (`KodeProses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_aktivitas`
--

LOCK TABLES `t_master_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_master_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_aktivitas_satuan`
--

DROP TABLE IF EXISTS `t_master_aktivitas_satuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_aktivitas_satuan` (
  `IDSatuanLain` int(11) NOT NULL AUTO_INCREMENT,
  `IDProses` int(11) NOT NULL,
  `Tingkat` int(11) NOT NULL DEFAULT '0',
  `Satuan` varchar(20) NOT NULL,
  `VolumeDariSebelumnya` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDSatuanLain`),
  KEY `IDProses` (`IDProses`),
  CONSTRAINT `t_master_aktivitas_satuan_ibfk_1` FOREIGN KEY (`IDProses`) REFERENCES `t_master_aktivitas` (`IDProses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_aktivitas_satuan`
--

LOCK TABLES `t_master_aktivitas_satuan` WRITE;
/*!40000 ALTER TABLE `t_master_aktivitas_satuan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_aktivitas_satuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_bahan`
--

DROP TABLE IF EXISTS `t_master_bahan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_bahan` (
  `IDBahan` int(11) NOT NULL AUTO_INCREMENT,
  `KodeBahan` varchar(8) NOT NULL,
  `JenisBahan` enum('BAKU','INPUT PRE-PRIMARY','OUTPUT PRE-PRIMARY','CAMPURAN INPUT PRE-PRIMARY','INPUT PRIMARY','OUTPUT PRIMARY') NOT NULL DEFAULT 'INPUT PRE-PRIMARY' COMMENT 'INPUT PRE-PRIMARY\r\nOUTPUT PRE-PRIMARY\r',
  `Nama` varchar(35) NOT NULL,
  `PenyusutanPerHari` float DEFAULT '0',
  `Keterangan` varchar(100) DEFAULT NULL,
  `Stok` int(11) DEFAULT '0',
  `IDSupplier` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDBahan`),
  UNIQUE KEY `KodeBahan` (`KodeBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_bahan`
--

LOCK TABLES `t_master_bahan` WRITE;
/*!40000 ALTER TABLE `t_master_bahan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_bahan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_bahan_satuan`
--

DROP TABLE IF EXISTS `t_master_bahan_satuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_bahan_satuan` (
  `IDSatuanLain` int(11) NOT NULL AUTO_INCREMENT,
  `IDBahan` int(11) NOT NULL,
  `Tingkat` int(11) NOT NULL DEFAULT '0',
  `Satuan` varchar(20) NOT NULL,
  `VolumeDariSebelumnya` float NOT NULL DEFAULT '1',
  `PenyusutanPerHari` float NOT NULL DEFAULT '0',
  `StokMinimum` float DEFAULT NULL,
  PRIMARY KEY (`IDSatuanLain`),
  KEY `IDBahan` (`IDBahan`),
  CONSTRAINT `t_master_bahan_satuan_ibfk_1` FOREIGN KEY (`IDBahan`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_bahan_satuan`
--

LOCK TABLES `t_master_bahan_satuan` WRITE;
/*!40000 ALTER TABLE `t_master_bahan_satuan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_bahan_satuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_bahanpendukung`
--

DROP TABLE IF EXISTS `t_master_bahanpendukung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_bahanpendukung` (
  `IDBahan` int(11) NOT NULL AUTO_INCREMENT,
  `KodeBahan` varchar(8) NOT NULL,
  `Nama` varchar(35) NOT NULL,
  `PenyusutanPerHari` float DEFAULT '0',
  `Keterangan` varchar(100) DEFAULT NULL,
  `Stok` int(11) DEFAULT NULL,
  `IDSupplier` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDBahan`),
  UNIQUE KEY `KodeBahan` (`KodeBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_bahanpendukung`
--

LOCK TABLES `t_master_bahanpendukung` WRITE;
/*!40000 ALTER TABLE `t_master_bahanpendukung` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_bahanpendukung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_bahanpendukung_satuan`
--

DROP TABLE IF EXISTS `t_master_bahanpendukung_satuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_bahanpendukung_satuan` (
  `IDSatuanLain` int(11) NOT NULL AUTO_INCREMENT,
  `IDBahan` int(11) NOT NULL,
  `Tingkat` int(11) NOT NULL DEFAULT '0',
  `Satuan` varchar(20) NOT NULL,
  `VolumeDariSebelumnya` float NOT NULL DEFAULT '1',
  `PenyusutanPerHari` float NOT NULL DEFAULT '0',
  `StokMinimum` float DEFAULT NULL,
  PRIMARY KEY (`IDSatuanLain`),
  KEY `IDBahan` (`IDBahan`),
  CONSTRAINT `t_master_bahanpendukung_satuan_ibfk_1` FOREIGN KEY (`IDBahan`) REFERENCES `t_master_bahanpendukung` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_bahanpendukung_satuan`
--

LOCK TABLES `t_master_bahanpendukung_satuan` WRITE;
/*!40000 ALTER TABLE `t_master_bahanpendukung_satuan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_bahanpendukung_satuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_gudang`
--

DROP TABLE IF EXISTS `t_master_gudang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_gudang` (
  `IDGudang` int(11) NOT NULL AUTO_INCREMENT,
  `KodeGudang` varchar(5) NOT NULL,
  `NamaGudang` varchar(35) NOT NULL,
  `Alamat` varchar(50) DEFAULT NULL,
  `NoTelpon` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`IDGudang`),
  UNIQUE KEY `KodeGudang` (`KodeGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_gudang`
--

LOCK TABLES `t_master_gudang` WRITE;
/*!40000 ALTER TABLE `t_master_gudang` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_gudang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_jasaekspedisi`
--

DROP TABLE IF EXISTS `t_master_jasaekspedisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_jasaekspedisi` (
  `IDEkspedisi` int(11) NOT NULL,
  `KodeEkspedisi` varchar(13) NOT NULL,
  `NamaPerusahaan` varchar(35) NOT NULL,
  `Alamat` varchar(40) NOT NULL,
  `NoTelpon` varchar(20) DEFAULT NULL,
  `NoFax` varchar(20) DEFAULT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDEkspedisi`),
  UNIQUE KEY `KodeEkspedisi` (`KodeEkspedisi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_jasaekspedisi`
--

LOCK TABLES `t_master_jasaekspedisi` WRITE;
/*!40000 ALTER TABLE `t_master_jasaekspedisi` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_jasaekspedisi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_kernet`
--

DROP TABLE IF EXISTS `t_master_kernet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_kernet` (
  `IDKernet` int(11) NOT NULL,
  `KodeKernet` varchar(13) NOT NULL,
  `Nama` varchar(35) NOT NULL,
  `Alamat` varchar(40) NOT NULL DEFAULT 'LAKI-LAKI',
  `NoKTP` varchar(20) NOT NULL,
  PRIMARY KEY (`IDKernet`),
  UNIQUE KEY `KodeKernet` (`KodeKernet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_kernet`
--

LOCK TABLES `t_master_kernet` WRITE;
/*!40000 ALTER TABLE `t_master_kernet` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_kernet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_mesin`
--

DROP TABLE IF EXISTS `t_master_mesin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_mesin` (
  `IDMesin` int(11) NOT NULL AUTO_INCREMENT,
  `KodeMesin` varchar(13) NOT NULL,
  `Nama` varchar(35) NOT NULL,
  `Merk` varchar(30) NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDMesin`),
  UNIQUE KEY `KodeMesin` (`KodeMesin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_mesin`
--

LOCK TABLES `t_master_mesin` WRITE;
/*!40000 ALTER TABLE `t_master_mesin` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_mesin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_mobil`
--

DROP TABLE IF EXISTS `t_master_mobil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_mobil` (
  `IDMobil` int(11) NOT NULL AUTO_INCREMENT,
  `NomorPolisi` varchar(10) NOT NULL,
  `Merk` varchar(20) NOT NULL,
  `Warna` varchar(15) NOT NULL,
  `Kapasitas` float DEFAULT NULL,
  PRIMARY KEY (`IDMobil`),
  UNIQUE KEY `KodeMesin` (`NomorPolisi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_mobil`
--

LOCK TABLES `t_master_mobil` WRITE;
/*!40000 ALTER TABLE `t_master_mobil` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_mobil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_rokok`
--

DROP TABLE IF EXISTS `t_master_rokok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_rokok` (
  `IDRokok` int(11) NOT NULL AUTO_INCREMENT,
  `KodeRokok` varchar(8) NOT NULL,
  `MerkDagang` varchar(35) NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `Stok` int(11) DEFAULT '0',
  PRIMARY KEY (`IDRokok`),
  UNIQUE KEY `KodeRokok` (`KodeRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_rokok`
--

LOCK TABLES `t_master_rokok` WRITE;
/*!40000 ALTER TABLE `t_master_rokok` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_rokok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_rokok_satuan`
--

DROP TABLE IF EXISTS `t_master_rokok_satuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_rokok_satuan` (
  `IDSatuanLain` int(11) NOT NULL AUTO_INCREMENT,
  `IDRokok` int(11) NOT NULL,
  `Tingkat` int(11) NOT NULL DEFAULT '0',
  `Satuan` varchar(20) NOT NULL,
  `VolumeDariSebelumnya` float NOT NULL DEFAULT '1',
  `StokMinimum` float DEFAULT NULL,
  PRIMARY KEY (`IDSatuanLain`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_master_rokok_satuan_ibfk_1` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_rokok_satuan`
--

LOCK TABLES `t_master_rokok_satuan` WRITE;
/*!40000 ALTER TABLE `t_master_rokok_satuan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_rokok_satuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_supir`
--

DROP TABLE IF EXISTS `t_master_supir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_supir` (
  `IDSupir` int(11) NOT NULL AUTO_INCREMENT,
  `KodeSupir` varchar(13) NOT NULL,
  `Nama` varchar(35) NOT NULL,
  `Alamat` varchar(40) NOT NULL DEFAULT 'LAKI-LAKI',
  `NoKTP` varchar(20) NOT NULL,
  `NoSIM` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`IDSupir`),
  UNIQUE KEY `KodeSupir` (`KodeSupir`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_supir`
--

LOCK TABLES `t_master_supir` WRITE;
/*!40000 ALTER TABLE `t_master_supir` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_supir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_master_supplier`
--

DROP TABLE IF EXISTS `t_master_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_master_supplier` (
  `IDSupplier` int(11) NOT NULL AUTO_INCREMENT,
  `KodeSupplier` varchar(10) NOT NULL,
  `Nama` varchar(35) NOT NULL,
  `NamaPenanggungJawab` varchar(35) DEFAULT NULL,
  `Alamat` varchar(40) DEFAULT NULL,
  `NoTelepon` varchar(20) DEFAULT NULL,
  `NoFax` varchar(20) DEFAULT NULL,
  `NoHP` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`IDSupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_master_supplier`
--

LOCK TABLES `t_master_supplier` WRITE;
/*!40000 ALTER TABLE `t_master_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_master_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_beritaacara_delivery`
--

DROP TABLE IF EXISTS `t_trans_beritaacara_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_beritaacara_delivery` (
  `IDDelivery` int(11) NOT NULL,
  `IDRokokKeluar` int(11) NOT NULL,
  `NomorDeliveryOrder` varchar(20) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `CaraKirim` enum('KIRIM SENDIRI','VIA EKSPEDISI') NOT NULL DEFAULT 'KIRIM SENDIRI' COMMENT 'KIRIM SENDIRI\r',
  `IDSupir` int(11) DEFAULT NULL,
  `IDKernet` int(11) DEFAULT NULL,
  `IDMobil` int(11) DEFAULT NULL,
  `IDEkspedisi` int(11) DEFAULT NULL,
  `IDGudang` int(11) DEFAULT NULL,
  `IDPurchaseOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDDelivery`),
  KEY `IDRokokKeluar` (`IDRokokKeluar`),
  KEY `IDSupir` (`IDSupir`),
  KEY `IDKernet` (`IDKernet`),
  KEY `IDMobil` (`IDMobil`),
  KEY `IDEkspedisi` (`IDEkspedisi`),
  KEY `IDGudang` (`IDGudang`),
  CONSTRAINT `t_trans_beritaacara_delivery_ibfk_1` FOREIGN KEY (`IDRokokKeluar`) REFERENCES `t_trans_keluar_rokok` (`IDRokokKeluar`),
  CONSTRAINT `t_trans_beritaacara_delivery_ibfk_2` FOREIGN KEY (`IDSupir`) REFERENCES `t_master_supir` (`IDSupir`),
  CONSTRAINT `t_trans_beritaacara_delivery_ibfk_3` FOREIGN KEY (`IDKernet`) REFERENCES `t_master_kernet` (`IDKernet`),
  CONSTRAINT `t_trans_beritaacara_delivery_ibfk_4` FOREIGN KEY (`IDMobil`) REFERENCES `t_master_mobil` (`IDMobil`),
  CONSTRAINT `t_trans_beritaacara_delivery_ibfk_5` FOREIGN KEY (`IDEkspedisi`) REFERENCES `t_master_jasaekspedisi` (`IDEkspedisi`),
  CONSTRAINT `t_trans_beritaacara_delivery_ibfk_6` FOREIGN KEY (`IDGudang`) REFERENCES `t_master_gudang` (`IDGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_beritaacara_delivery`
--

LOCK TABLES `t_trans_beritaacara_delivery` WRITE;
/*!40000 ALTER TABLE `t_trans_beritaacara_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_beritaacara_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_beritaacara_preprimary`
--

DROP TABLE IF EXISTS `t_trans_beritaacara_preprimary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_beritaacara_preprimary` (
  `IDBAPrePrimary` int(11) NOT NULL AUTO_INCREMENT,
  `IDSPKPrePrimary` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `MulaiProduksi` datetime NOT NULL,
  `SelesaiProduksi` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `IDMesin` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDBAPrePrimary`),
  KEY `IDSPKPrePrimary` (`IDSPKPrePrimary`),
  CONSTRAINT `t_trans_beritaacara_preprimary_ibfk_1` FOREIGN KEY (`IDSPKPrePrimary`) REFERENCES `t_trans_spk_preprimary` (`IDSPKPrePrimary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_beritaacara_preprimary`
--

LOCK TABLES `t_trans_beritaacara_preprimary` WRITE;
/*!40000 ALTER TABLE `t_trans_beritaacara_preprimary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_beritaacara_preprimary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_beritaacara_primary`
--

DROP TABLE IF EXISTS `t_trans_beritaacara_primary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_beritaacara_primary` (
  `IDBAPrimary` int(11) NOT NULL AUTO_INCREMENT,
  `IDSPKPrimary` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `MulaiProduksi` datetime NOT NULL,
  `SelesaiProduksi` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `IDMesin` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDBAPrimary`),
  KEY `IDSPKPrimary` (`IDSPKPrimary`),
  CONSTRAINT `t_trans_beritaacara_primary_ibfk_1` FOREIGN KEY (`IDSPKPrimary`) REFERENCES `t_trans_spk_primary` (`IDSPKPrimary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_beritaacara_primary`
--

LOCK TABLES `t_trans_beritaacara_primary` WRITE;
/*!40000 ALTER TABLE `t_trans_beritaacara_primary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_beritaacara_primary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_beritaacara_secondary`
--

DROP TABLE IF EXISTS `t_trans_beritaacara_secondary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_beritaacara_secondary` (
  `IDBASecondary` int(11) NOT NULL AUTO_INCREMENT,
  `IDSPKSecondary` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `MulaiProduksi` datetime NOT NULL,
  `SelesaiProduksi` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `IDMesin` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDBASecondary`),
  KEY `IDSPKSecondary` (`IDSPKSecondary`),
  CONSTRAINT `t_trans_beritaacara_secondary_ibfk_1` FOREIGN KEY (`IDSPKSecondary`) REFERENCES `t_trans_spk_secondary` (`IDSPKSecondary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_beritaacara_secondary`
--

LOCK TABLES `t_trans_beritaacara_secondary` WRITE;
/*!40000 ALTER TABLE `t_trans_beritaacara_secondary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_beritaacara_secondary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_delivery`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_delivery` (
  `IDDetailDelivery` int(11) NOT NULL AUTO_INCREMENT,
  `IDDelivery` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailDelivery`),
  KEY `IDDelivery` (`IDDelivery`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_trans_detail_beritaacara_delivery_ibfk_1` FOREIGN KEY (`IDDelivery`) REFERENCES `t_trans_beritaacara_delivery` (`IDDelivery`),
  CONSTRAINT `t_trans_detail_beritaacara_delivery_ibfk_2` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_delivery`
--

LOCK TABLES `t_trans_detail_beritaacara_delivery` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_preprimary`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_preprimary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_preprimary` (
  `IDDetailBAPrePrimary` int(11) NOT NULL AUTO_INCREMENT,
  `IDBAPrePrimary` int(11) NOT NULL,
  `IDBOPP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBAPrePrimary`),
  KEY `IDBAPrePrimary` (`IDBAPrePrimary`),
  KEY `IDBOPP` (`IDBOPP`),
  CONSTRAINT `t_trans_detail_beritaacara_preprimary_ibfk_1` FOREIGN KEY (`IDBAPrePrimary`) REFERENCES `t_trans_beritaacara_preprimary` (`IDBAPrePrimary`),
  CONSTRAINT `t_trans_detail_beritaacara_preprimary_ibfk_2` FOREIGN KEY (`IDBOPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_preprimary`
--

LOCK TABLES `t_trans_detail_beritaacara_preprimary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_preprimary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_preprimary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_preprimary_aktivitas`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_preprimary_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_preprimary_aktivitas` (
  `IDDetailBAPrePrimary_Aktivitas` int(11) NOT NULL AUTO_INCREMENT,
  `IDBAPrePrimary` int(11) NOT NULL,
  `IDProses` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBAPrePrimary_Aktivitas`),
  KEY `IDBAPrePrimary` (`IDBAPrePrimary`),
  KEY `IDProses` (`IDProses`),
  CONSTRAINT `t_trans_detail_beritaacara_preprimary_aktivitas_ibfk_1` FOREIGN KEY (`IDBAPrePrimary`) REFERENCES `t_trans_beritaacara_preprimary` (`IDBAPrePrimary`),
  CONSTRAINT `t_trans_detail_beritaacara_preprimary_aktivitas_ibfk_2` FOREIGN KEY (`IDProses`) REFERENCES `t_master_aktivitas` (`IDProses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_preprimary_aktivitas`
--

LOCK TABLES `t_trans_detail_beritaacara_preprimary_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_preprimary_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_preprimary_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_preprimary_bipp`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_preprimary_bipp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_preprimary_bipp` (
  `IDDetailBAPrePrimary_BIPP` int(11) NOT NULL AUTO_INCREMENT,
  `IDBAPrePrimary` int(11) NOT NULL,
  `IDBIPP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBAPrePrimary_BIPP`),
  KEY `IDBAPrePrimary` (`IDBAPrePrimary`),
  KEY `IDBIPP` (`IDBIPP`),
  CONSTRAINT `t_trans_detail_beritaacara_preprimary_bipp_ibfk_1` FOREIGN KEY (`IDBAPrePrimary`) REFERENCES `t_trans_beritaacara_preprimary` (`IDBAPrePrimary`),
  CONSTRAINT `t_trans_detail_beritaacara_preprimary_bipp_ibfk_2` FOREIGN KEY (`IDBIPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_preprimary_bipp`
--

LOCK TABLES `t_trans_detail_beritaacara_preprimary_bipp` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_preprimary_bipp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_preprimary_bipp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_primary`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_primary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_primary` (
  `IDDetailBAPrimary` int(11) NOT NULL AUTO_INCREMENT,
  `IDBAPrimary` int(11) NOT NULL,
  `IDBOP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBAPrimary`),
  KEY `IDBAPrimary` (`IDBAPrimary`),
  KEY `IDBOP` (`IDBOP`),
  CONSTRAINT `t_trans_detail_beritaacara_primary_ibfk_1` FOREIGN KEY (`IDBAPrimary`) REFERENCES `t_trans_beritaacara_primary` (`IDBAPrimary`),
  CONSTRAINT `t_trans_detail_beritaacara_primary_ibfk_2` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_primary`
--

LOCK TABLES `t_trans_detail_beritaacara_primary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_primary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_primary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_primary_aktivitas`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_primary_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_primary_aktivitas` (
  `IDDetailBAPrimary_Aktivitas` int(11) NOT NULL AUTO_INCREMENT,
  `IDBAPrimary` int(11) NOT NULL,
  `IDProses` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBAPrimary_Aktivitas`),
  KEY `IDBAPrimary` (`IDBAPrimary`),
  KEY `IDProses` (`IDProses`),
  CONSTRAINT `t_trans_detail_beritaacara_primary_aktivitas_ibfk_1` FOREIGN KEY (`IDBAPrimary`) REFERENCES `t_trans_beritaacara_primary` (`IDBAPrimary`),
  CONSTRAINT `t_trans_detail_beritaacara_primary_aktivitas_ibfk_2` FOREIGN KEY (`IDProses`) REFERENCES `t_master_aktivitas` (`IDProses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_primary_aktivitas`
--

LOCK TABLES `t_trans_detail_beritaacara_primary_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_primary_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_primary_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_primary_bopp`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_primary_bopp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_primary_bopp` (
  `IDDetailBAPrimary_BOPP` int(11) NOT NULL AUTO_INCREMENT,
  `IDBAPrimary` int(11) NOT NULL,
  `IDBOPP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBAPrimary_BOPP`),
  KEY `IDBAPrimary` (`IDBAPrimary`),
  KEY `IDBOPP` (`IDBOPP`),
  CONSTRAINT `t_trans_detail_beritaacara_primary_bopp_ibfk_1` FOREIGN KEY (`IDBAPrimary`) REFERENCES `t_trans_beritaacara_primary` (`IDBAPrimary`),
  CONSTRAINT `t_trans_detail_beritaacara_primary_bopp_ibfk_2` FOREIGN KEY (`IDBOPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_primary_bopp`
--

LOCK TABLES `t_trans_detail_beritaacara_primary_bopp` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_primary_bopp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_primary_bopp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_secondary`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_secondary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_secondary` (
  `IDDetailBASecondary` int(11) NOT NULL AUTO_INCREMENT,
  `IDBASecondary` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBASecondary`),
  KEY `IDBASecondary` (`IDBASecondary`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_ibfk_1` FOREIGN KEY (`IDBASecondary`) REFERENCES `t_trans_beritaacara_secondary` (`IDBASecondary`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_ibfk_2` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_secondary`
--

LOCK TABLES `t_trans_detail_beritaacara_secondary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_secondary_aktivitas`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_secondary_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_secondary_aktivitas` (
  `IDDetailBASecondary_Aktivitas` int(11) NOT NULL AUTO_INCREMENT,
  `IDBASecondary` int(11) NOT NULL,
  `IDProses` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBASecondary_Aktivitas`),
  KEY `IDBASecondary` (`IDBASecondary`),
  KEY `IDProses` (`IDProses`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_aktivitas_ibfk_1` FOREIGN KEY (`IDBASecondary`) REFERENCES `t_trans_beritaacara_secondary` (`IDBASecondary`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_aktivitas_ibfk_2` FOREIGN KEY (`IDProses`) REFERENCES `t_master_aktivitas` (`IDProses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_secondary_aktivitas`
--

LOCK TABLES `t_trans_detail_beritaacara_secondary_aktivitas` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary_aktivitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_secondary_bop`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_secondary_bop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_secondary_bop` (
  `IDDetailBASecondary_BOP` int(11) NOT NULL AUTO_INCREMENT,
  `IDBASecondary` int(11) NOT NULL,
  `IDBOP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBASecondary_BOP`),
  KEY `IDBASecondary` (`IDBASecondary`),
  KEY `IDBOP` (`IDBOP`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_bop_ibfk_1` FOREIGN KEY (`IDBASecondary`) REFERENCES `t_trans_beritaacara_secondary` (`IDBASecondary`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_bop_ibfk_2` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_secondary_bop`
--

LOCK TABLES `t_trans_detail_beritaacara_secondary_bop` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary_bop` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary_bop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_beritaacara_secondary_bp`
--

DROP TABLE IF EXISTS `t_trans_detail_beritaacara_secondary_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_beritaacara_secondary_bp` (
  `IDDetailBASecondary_BP` int(11) NOT NULL AUTO_INCREMENT,
  `IDBASecondary` int(11) NOT NULL,
  `IDBP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBASecondary_BP`),
  KEY `IDBASecondary` (`IDBASecondary`),
  KEY `IDBP` (`IDBP`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_bp_ibfk_1` FOREIGN KEY (`IDBASecondary`) REFERENCES `t_trans_beritaacara_secondary` (`IDBASecondary`),
  CONSTRAINT `t_trans_detail_beritaacara_secondary_bp_ibfk_2` FOREIGN KEY (`IDBP`) REFERENCES `t_master_bahanpendukung` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_beritaacara_secondary_bp`
--

LOCK TABLES `t_trans_detail_beritaacara_secondary_bp` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_beritaacara_secondary_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_fakturpenjualan`
--

DROP TABLE IF EXISTS `t_trans_detail_fakturpenjualan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_fakturpenjualan` (
  `IDDetailFakturPenjualan` int(11) NOT NULL,
  `IDFakturPenjualan` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailFakturPenjualan`),
  KEY `IDFakturPenjualan` (`IDFakturPenjualan`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_trans_detail_fakturpenjualan_ibfk_1` FOREIGN KEY (`IDFakturPenjualan`) REFERENCES `t_trans_fakturpenjualan` (`IDFakturPenjualan`),
  CONSTRAINT `t_trans_detail_fakturpenjualan_ibfk_2` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_fakturpenjualan`
--

LOCK TABLES `t_trans_detail_fakturpenjualan` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_fakturpenjualan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_fakturpenjualan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_keluar_rokok`
--

DROP TABLE IF EXISTS `t_trans_detail_keluar_rokok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_keluar_rokok` (
  `IDDetailRokokKeluar` int(11) NOT NULL AUTO_INCREMENT,
  `IDRokokKeluar` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailRokokKeluar`),
  KEY `IDBIPPMasuk` (`IDRokokKeluar`),
  KEY `IDBIPP` (`IDRokok`),
  CONSTRAINT `t_trans_detail_keluar_rokok_ibfk_1` FOREIGN KEY (`IDRokokKeluar`) REFERENCES `t_trans_keluar_rokok` (`IDRokokKeluar`),
  CONSTRAINT `t_trans_detail_keluar_rokok_ibfk_2` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_keluar_rokok`
--

LOCK TABLES `t_trans_detail_keluar_rokok` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_keluar_rokok` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_keluar_rokok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_masuk_bipp`
--

DROP TABLE IF EXISTS `t_trans_detail_masuk_bipp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_masuk_bipp` (
  `IDDetailBIPPMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `IDBIPPMasuk` int(11) NOT NULL,
  `IDBIPP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBIPPMasuk`),
  KEY `IDBIPPMasuk` (`IDBIPPMasuk`),
  KEY `IDBIPP` (`IDBIPP`),
  CONSTRAINT `t_trans_detail_masuk_bipp_ibfk_1` FOREIGN KEY (`IDBIPPMasuk`) REFERENCES `t_trans_masuk_bipp` (`IDBIPPMasuk`),
  CONSTRAINT `t_trans_detail_masuk_bipp_ibfk_2` FOREIGN KEY (`IDBIPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_masuk_bipp`
--

LOCK TABLES `t_trans_detail_masuk_bipp` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_masuk_bipp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_masuk_bipp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_masuk_bp`
--

DROP TABLE IF EXISTS `t_trans_detail_masuk_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_masuk_bp` (
  `IDDetailBPMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `IDBPMasuk` int(11) NOT NULL,
  `IDBP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailBPMasuk`),
  KEY `IDBP` (`IDBP`),
  KEY `IDBPMasuk` (`IDBPMasuk`),
  CONSTRAINT `t_trans_detail_masuk_bp_ibfk_1` FOREIGN KEY (`IDBP`) REFERENCES `t_master_bahanpendukung` (`IDBahan`),
  CONSTRAINT `t_trans_detail_masuk_bp_ibfk_2` FOREIGN KEY (`IDBPMasuk`) REFERENCES `t_trans_masuk_bp` (`IDBPMasuk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_masuk_bp`
--

LOCK TABLES `t_trans_detail_masuk_bp` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_masuk_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_masuk_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_order_preprimary`
--

DROP TABLE IF EXISTS `t_trans_detail_order_preprimary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_order_preprimary` (
  `IDDetailOrderPrePrimary` int(11) NOT NULL AUTO_INCREMENT,
  `IDOrderPrePrimary` int(11) NOT NULL,
  `IDBOPP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailOrderPrePrimary`),
  KEY `IDOrderPrePrimary` (`IDOrderPrePrimary`),
  KEY `IDBOPP` (`IDBOPP`),
  CONSTRAINT `t_trans_detail_order_preprimary_ibfk_1` FOREIGN KEY (`IDOrderPrePrimary`) REFERENCES `t_trans_order_preprimary` (`IDOrderPrePrimary`),
  CONSTRAINT `t_trans_detail_order_preprimary_ibfk_2` FOREIGN KEY (`IDBOPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_order_preprimary`
--

LOCK TABLES `t_trans_detail_order_preprimary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_order_preprimary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_order_preprimary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_order_primary`
--

DROP TABLE IF EXISTS `t_trans_detail_order_primary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_order_primary` (
  `IDDetailOrderPrimary` int(11) NOT NULL,
  `IDOrderPrimary` int(11) NOT NULL,
  `IDBOP` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailOrderPrimary`),
  KEY `IDOrderPrimary` (`IDOrderPrimary`),
  KEY `IDBOP` (`IDBOP`),
  CONSTRAINT `t_trans_detail_order_primary_ibfk_1` FOREIGN KEY (`IDOrderPrimary`) REFERENCES `t_trans_order_primary` (`IDOrderPrimary`),
  CONSTRAINT `t_trans_detail_order_primary_ibfk_2` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_order_primary`
--

LOCK TABLES `t_trans_detail_order_primary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_order_primary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_order_primary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_order_secondary`
--

DROP TABLE IF EXISTS `t_trans_detail_order_secondary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_order_secondary` (
  `IDDetailOrderSecondary` int(11) NOT NULL,
  `IDOrderSecondary` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`IDDetailOrderSecondary`),
  KEY `IDOrderSecondary` (`IDOrderSecondary`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_trans_detail_order_secondary_ibfk_1` FOREIGN KEY (`IDOrderSecondary`) REFERENCES `t_trans_order_secondary` (`IDOrderSecondary`),
  CONSTRAINT `t_trans_detail_order_secondary_ibfk_2` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_order_secondary`
--

LOCK TABLES `t_trans_detail_order_secondary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_order_secondary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_order_secondary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_purchaseorder`
--

DROP TABLE IF EXISTS `t_trans_detail_purchaseorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_purchaseorder` (
  `IDDetailTrans` int(11) NOT NULL AUTO_INCREMENT,
  `IDTrans` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Volume` float NOT NULL DEFAULT '1',
  `Harga` float NOT NULL,
  PRIMARY KEY (`IDDetailTrans`),
  KEY `IDTrans` (`IDTrans`),
  CONSTRAINT `t_trans_detail_purchaseorder_ibfk_1` FOREIGN KEY (`IDTrans`) REFERENCES `t_trans_purchaseorder` (`IDTrans`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_purchaseorder`
--

LOCK TABLES `t_trans_detail_purchaseorder` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_purchaseorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_purchaseorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_spk_preprimary`
--

DROP TABLE IF EXISTS `t_trans_detail_spk_preprimary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_spk_preprimary` (
  `IDDetailSPKPrePrimary` int(11) NOT NULL AUTO_INCREMENT,
  `IDSPKPrePrimary` int(11) NOT NULL,
  `IDBOPP` int(11) NOT NULL,
  `Volume` float NOT NULL,
  PRIMARY KEY (`IDDetailSPKPrePrimary`),
  KEY `IDSPKPrePrimary` (`IDSPKPrePrimary`),
  KEY `IDBOPP` (`IDBOPP`),
  CONSTRAINT `t_trans_detail_spk_preprimary_ibfk_1` FOREIGN KEY (`IDSPKPrePrimary`) REFERENCES `t_trans_spk_preprimary` (`IDSPKPrePrimary`),
  CONSTRAINT `t_trans_detail_spk_preprimary_ibfk_2` FOREIGN KEY (`IDBOPP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_spk_preprimary`
--

LOCK TABLES `t_trans_detail_spk_preprimary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_spk_preprimary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_spk_preprimary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_spk_primary`
--

DROP TABLE IF EXISTS `t_trans_detail_spk_primary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_spk_primary` (
  `IDDetailSPKPrimary` int(11) NOT NULL AUTO_INCREMENT,
  `IDSPKPrimary` int(11) NOT NULL,
  `IDBOP` int(11) NOT NULL,
  `Volume` float NOT NULL,
  PRIMARY KEY (`IDDetailSPKPrimary`),
  KEY `IDSPKPrePrimary` (`IDSPKPrimary`),
  KEY `IDBOPP` (`IDBOP`),
  CONSTRAINT `t_trans_detail_spk_primary_ibfk_1` FOREIGN KEY (`IDSPKPrimary`) REFERENCES `t_trans_spk_primary` (`IDSPKPrimary`),
  CONSTRAINT `t_trans_detail_spk_primary_ibfk_2` FOREIGN KEY (`IDBOP`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_spk_primary`
--

LOCK TABLES `t_trans_detail_spk_primary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_spk_primary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_spk_primary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_spk_secondary`
--

DROP TABLE IF EXISTS `t_trans_detail_spk_secondary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_spk_secondary` (
  `IDDetailSPKSecondary` int(11) NOT NULL AUTO_INCREMENT,
  `IDSPKSecondary` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Volume` float NOT NULL,
  PRIMARY KEY (`IDDetailSPKSecondary`),
  KEY `IDSPKPrePrimary` (`IDSPKSecondary`),
  KEY `IDBOPP` (`IDRokok`),
  CONSTRAINT `t_trans_detail_spk_secondary_ibfk_1` FOREIGN KEY (`IDSPKSecondary`) REFERENCES `t_trans_spk_secondary` (`IDSPKSecondary`),
  CONSTRAINT `t_trans_detail_spk_secondary_ibfk_2` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_spk_secondary`
--

LOCK TABLES `t_trans_detail_spk_secondary` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_spk_secondary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_spk_secondary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_stokopname_bahan`
--

DROP TABLE IF EXISTS `t_trans_detail_stokopname_bahan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_stokopname_bahan` (
  `IDDetailStokOpname_Bahan` int(11) NOT NULL AUTO_INCREMENT,
  `IDStokOpname` int(11) NOT NULL,
  `IDBahan` int(11) NOT NULL,
  `Tercatat` float NOT NULL,
  `Aktual` float NOT NULL,
  `Alasan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDDetailStokOpname_Bahan`),
  KEY `IDStokOpname` (`IDStokOpname`),
  KEY `IDBahan` (`IDBahan`),
  CONSTRAINT `t_trans_detail_stokopname_bahan_ibfk_1` FOREIGN KEY (`IDStokOpname`) REFERENCES `t_trans_stokopname` (`IDStokOpname`),
  CONSTRAINT `t_trans_detail_stokopname_bahan_ibfk_2` FOREIGN KEY (`IDBahan`) REFERENCES `t_master_bahan` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_stokopname_bahan`
--

LOCK TABLES `t_trans_detail_stokopname_bahan` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_stokopname_bahan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_stokopname_bahan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_stokopname_bp`
--

DROP TABLE IF EXISTS `t_trans_detail_stokopname_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_stokopname_bp` (
  `IDDetailStokOpname_BP` int(11) NOT NULL AUTO_INCREMENT,
  `IDStokOpname` int(11) NOT NULL,
  `IDBahanPendukung` int(11) NOT NULL,
  `Tercatat` float NOT NULL,
  `Aktual` float NOT NULL,
  `Alasan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDDetailStokOpname_BP`),
  KEY `IDStokOpname` (`IDStokOpname`),
  KEY `IDBahanPendukung` (`IDBahanPendukung`),
  CONSTRAINT `t_trans_detail_stokopname_bp_ibfk_1` FOREIGN KEY (`IDStokOpname`) REFERENCES `t_trans_stokopname` (`IDStokOpname`),
  CONSTRAINT `t_trans_detail_stokopname_bp_ibfk_2` FOREIGN KEY (`IDBahanPendukung`) REFERENCES `t_master_bahanpendukung` (`IDBahan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_stokopname_bp`
--

LOCK TABLES `t_trans_detail_stokopname_bp` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_stokopname_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_stokopname_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_detail_stokopname_rokok`
--

DROP TABLE IF EXISTS `t_trans_detail_stokopname_rokok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_detail_stokopname_rokok` (
  `IDDetailStokOpname_Rokok` int(11) NOT NULL AUTO_INCREMENT,
  `IDStokOpname` int(11) NOT NULL,
  `IDRokok` int(11) NOT NULL,
  `Tercatat` float NOT NULL,
  `Aktual` float NOT NULL,
  `Alasan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDDetailStokOpname_Rokok`),
  KEY `IDStokOpname` (`IDStokOpname`),
  KEY `IDRokok` (`IDRokok`),
  CONSTRAINT `t_trans_detail_stokopname_rokok_ibfk_1` FOREIGN KEY (`IDStokOpname`) REFERENCES `t_trans_stokopname` (`IDStokOpname`),
  CONSTRAINT `t_trans_detail_stokopname_rokok_ibfk_2` FOREIGN KEY (`IDRokok`) REFERENCES `t_master_rokok` (`IDRokok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_detail_stokopname_rokok`
--

LOCK TABLES `t_trans_detail_stokopname_rokok` WRITE;
/*!40000 ALTER TABLE `t_trans_detail_stokopname_rokok` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_detail_stokopname_rokok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_fakturpenjualan`
--

DROP TABLE IF EXISTS `t_trans_fakturpenjualan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_fakturpenjualan` (
  `IDFakturPenjualan` int(11) NOT NULL AUTO_INCREMENT,
  `NomorFakturPenjualan` varchar(20) NOT NULL,
  `NomorFakturExt` varchar(20) DEFAULT NULL,
  `IDPurchaseOrder` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `TanggalJatuhTempo` date DEFAULT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDFakturPenjualan`),
  UNIQUE KEY `NomorFakturPenjualan` (`NomorFakturPenjualan`),
  KEY `IDPurchaseOrder` (`IDPurchaseOrder`),
  CONSTRAINT `t_trans_fakturpenjualan_ibfk_1` FOREIGN KEY (`IDPurchaseOrder`) REFERENCES `t_trans_purchaseorder` (`IDTrans`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_fakturpenjualan`
--

LOCK TABLES `t_trans_fakturpenjualan` WRITE;
/*!40000 ALTER TABLE `t_trans_fakturpenjualan` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_fakturpenjualan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_keluar_rokok`
--

DROP TABLE IF EXISTS `t_trans_keluar_rokok`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_keluar_rokok` (
  `IDRokokKeluar` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `IDGudangAsal` int(11) DEFAULT NULL,
  `IDGudangTujuan` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDRokokKeluar`),
  KEY `IDGudangAsal` (`IDGudangAsal`),
  KEY `IDGudangTujuan` (`IDGudangTujuan`),
  CONSTRAINT `t_trans_keluar_rokok_ibfk_1` FOREIGN KEY (`IDGudangAsal`) REFERENCES `t_master_gudang` (`IDGudang`),
  CONSTRAINT `t_trans_keluar_rokok_ibfk_2` FOREIGN KEY (`IDGudangTujuan`) REFERENCES `t_master_gudang` (`IDGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_keluar_rokok`
--

LOCK TABLES `t_trans_keluar_rokok` WRITE;
/*!40000 ALTER TABLE `t_trans_keluar_rokok` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_keluar_rokok` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_masuk_bipp`
--

DROP TABLE IF EXISTS `t_trans_masuk_bipp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_masuk_bipp` (
  `IDBIPPMasuk` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `IDGudangAsal` int(11) DEFAULT NULL,
  `IDGudangTujuan` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDBIPPMasuk`),
  KEY `IDGudangAsal` (`IDGudangAsal`),
  KEY `IDGudangTujuan` (`IDGudangTujuan`),
  CONSTRAINT `t_trans_masuk_bipp_ibfk_1` FOREIGN KEY (`IDGudangAsal`) REFERENCES `t_master_gudang` (`IDGudang`),
  CONSTRAINT `t_trans_masuk_bipp_ibfk_2` FOREIGN KEY (`IDGudangTujuan`) REFERENCES `t_master_gudang` (`IDGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_masuk_bipp`
--

LOCK TABLES `t_trans_masuk_bipp` WRITE;
/*!40000 ALTER TABLE `t_trans_masuk_bipp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_masuk_bipp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_masuk_bp`
--

DROP TABLE IF EXISTS `t_trans_masuk_bp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_masuk_bp` (
  `IDBPMasuk` int(11) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime NOT NULL,
  `IDGudangAsal` int(11) DEFAULT NULL,
  `IDGudangTujuan` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDBPMasuk`),
  KEY `IDGudangAsal` (`IDGudangAsal`),
  KEY `IDGudangTujuan` (`IDGudangTujuan`),
  CONSTRAINT `t_trans_masuk_bp_ibfk_1` FOREIGN KEY (`IDGudangAsal`) REFERENCES `t_master_gudang` (`IDGudang`),
  CONSTRAINT `t_trans_masuk_bp_ibfk_2` FOREIGN KEY (`IDGudangTujuan`) REFERENCES `t_master_gudang` (`IDGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_masuk_bp`
--

LOCK TABLES `t_trans_masuk_bp` WRITE;
/*!40000 ALTER TABLE `t_trans_masuk_bp` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_masuk_bp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_order_preprimary`
--

DROP TABLE IF EXISTS `t_trans_order_preprimary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_order_preprimary` (
  `IDOrderPrePrimary` int(11) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `IDGudang` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDOrderPrePrimary`),
  KEY `IDGudang` (`IDGudang`),
  CONSTRAINT `t_trans_order_preprimary_ibfk_1` FOREIGN KEY (`IDGudang`) REFERENCES `t_master_gudang` (`IDGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_order_preprimary`
--

LOCK TABLES `t_trans_order_preprimary` WRITE;
/*!40000 ALTER TABLE `t_trans_order_preprimary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_order_preprimary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_order_primary`
--

DROP TABLE IF EXISTS `t_trans_order_primary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_order_primary` (
  `IDOrderPrimary` int(11) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `IDGudang` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDOrderPrimary`),
  KEY `IDGudang` (`IDGudang`),
  CONSTRAINT `t_trans_order_primary_ibfk_1` FOREIGN KEY (`IDGudang`) REFERENCES `t_master_gudang` (`IDGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_order_primary`
--

LOCK TABLES `t_trans_order_primary` WRITE;
/*!40000 ALTER TABLE `t_trans_order_primary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_order_primary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_order_secondary`
--

DROP TABLE IF EXISTS `t_trans_order_secondary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_order_secondary` (
  `IDOrderSecondary` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  `IDGudang` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDOrderSecondary`),
  KEY `IDGudang` (`IDGudang`),
  CONSTRAINT `t_trans_order_secondary_ibfk_1` FOREIGN KEY (`IDGudang`) REFERENCES `t_master_gudang` (`IDGudang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_order_secondary`
--

LOCK TABLES `t_trans_order_secondary` WRITE;
/*!40000 ALTER TABLE `t_trans_order_secondary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_order_secondary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_purchaseorder`
--

DROP TABLE IF EXISTS `t_trans_purchaseorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_purchaseorder` (
  `IDTrans` int(11) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime NOT NULL,
  `NoPurchaseOrder` varchar(20) NOT NULL,
  `NoNotaExt` varchar(20) DEFAULT NULL,
  `IDAgen` int(11) NOT NULL,
  `TanggalJatuhTempo` date DEFAULT NULL,
  PRIMARY KEY (`IDTrans`),
  UNIQUE KEY `NoPurchaseOrder` (`NoPurchaseOrder`),
  KEY `IDAgen` (`IDAgen`),
  CONSTRAINT `t_trans_purchaseorder_ibfk_1` FOREIGN KEY (`IDAgen`) REFERENCES `t_master_agen` (`IDAgen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_purchaseorder`
--

LOCK TABLES `t_trans_purchaseorder` WRITE;
/*!40000 ALTER TABLE `t_trans_purchaseorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_purchaseorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_spk_preprimary`
--

DROP TABLE IF EXISTS `t_trans_spk_preprimary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_spk_preprimary` (
  `IDSPKPrePrimary` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDSPKPrePrimary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_spk_preprimary`
--

LOCK TABLES `t_trans_spk_preprimary` WRITE;
/*!40000 ALTER TABLE `t_trans_spk_preprimary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_spk_preprimary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_spk_primary`
--

DROP TABLE IF EXISTS `t_trans_spk_primary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_spk_primary` (
  `IDSPKPrimary` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDSPKPrimary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_spk_primary`
--

LOCK TABLES `t_trans_spk_primary` WRITE;
/*!40000 ALTER TABLE `t_trans_spk_primary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_spk_primary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_spk_secondary`
--

DROP TABLE IF EXISTS `t_trans_spk_secondary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_spk_secondary` (
  `IDSPKSecondary` int(11) NOT NULL,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDSPKSecondary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_spk_secondary`
--

LOCK TABLES `t_trans_spk_secondary` WRITE;
/*!40000 ALTER TABLE `t_trans_spk_secondary` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_spk_secondary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_trans_stokopname`
--

DROP TABLE IF EXISTS `t_trans_stokopname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_trans_stokopname` (
  `IDStokOpname` int(11) NOT NULL AUTO_INCREMENT,
  `Tanggal` datetime NOT NULL,
  `Keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDStokOpname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_trans_stokopname`
--

LOCK TABLES `t_trans_stokopname` WRITE;
/*!40000 ALTER TABLE `t_trans_stokopname` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_trans_stokopname` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-09-20  1:33:47
