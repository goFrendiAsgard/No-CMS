<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of GroceryCrud_History_Harga_Aktivitas_Model
 *
 * @author No-CMS Module Generator
 */
class GroceryCrud_History_Harga_Aktivitas_Model  extends grocery_CRUD_Automatic_Model{

    public function __construct(){
        parent::__construct();
    }
}